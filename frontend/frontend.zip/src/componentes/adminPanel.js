import { useState } from "react";
import PendingUsers from "./usuariosPendientes";
import GestionEmpresas from "./gestionEmpresas";
import ListaAuditorias from "./listaAuditorias";
import NuevaAuditoria from "./nuevaAuditoria";
import ReclamoInforme from "./reclamoInforme";
import ReportesAuditorias from "./reportesAuditorias";

export default function AdminPanel({ logout }) {
  const [seccion, setSeccion] = useState("solicitudes");
  const [menuOpen, setMenuOpen] = useState(false);
  const [notificaciones, setNotificaciones] = useState([]);
  const [mostrarNotificaciones, setMostrarNotificaciones] = useState(false);

  const noLeidas = notificaciones.filter((n) => !n.leida).length;

  const cambiarSeccion = (nuevaSeccion) => {
    setSeccion(nuevaSeccion);
    setMenuOpen(false);
  };

  return (
    <div className="admin-layout">
      <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
        ☰
      </button>

      <div
        className="notification-bell"
        onClick={() => {
          setMostrarNotificaciones(!mostrarNotificaciones);
          setNotificaciones((prev) =>
            prev.map((n) => ({
              ...n,
              leida: true,
            }))
          );
        }}
      >
        🔔

        {noLeidas > 0 && <span className="notification-badge">{noLeidas}</span>}
      </div>

      {mostrarNotificaciones && (
        <div className="notifications-panel">
          {notificaciones.length === 0 ? (
            <p>No hay notificaciones</p>
          ) : (
            notificaciones.map((n) => (
              <div key={n.id} className="notification-item">
                <strong>{n.titulo}</strong>
                <p>{n.mensaje}</p>
              </div>
            ))
          )}
        </div>
      )}

      {menuOpen && (
        <div
          className="sidebar-backdrop"
          onClick={() => setMenuOpen(false)}
        ></div>
      )}

      <aside className={`sidebar ${menuOpen ? "open" : ""}`}>
        <h2>Panel Admin</h2>

        <button
          className={seccion === "solicitudes" ? "active" : ""}
          onClick={() => cambiarSeccion("solicitudes")}
        >
          Usuarios
        </button>

        <button
          className={seccion === "empresas" ? "active" : ""}
          onClick={() => cambiarSeccion("empresas")}
        >
          Gestión de empresas
        </button>

        <button
          className={seccion === "auditorias" ? "active" : ""}
          onClick={() => cambiarSeccion("auditorias")}
        >
          Todas las auditorías
        </button>

        <button
          className={seccion === "nueva" ? "active" : ""}
          onClick={() => cambiarSeccion("nueva")}
        >
          Nueva auditoria/evaluacion
        </button>

        <button
          className={seccion === "reclamos" ? "active" : ""}
          onClick={() => cambiarSeccion("reclamos")}
        >
          Reclamos / Informes
        </button>

        <button
          className={seccion === "reportes" ? "active" : ""}
          onClick={() => cambiarSeccion("reportes")}
        >
          Reportes
        </button>

        <button className="logout-button" onClick={logout}>
          Cerrar sesión
        </button>
      </aside>

      <main className="admin-content">
        {seccion === "solicitudes" && (
          <PendingUsers logout={logout} setNotificaciones={setNotificaciones} />
        )}

        {seccion === "empresas" && <GestionEmpresas logout={logout} />}

        {seccion === "auditorias" && (
          <ListaAuditorias modo="admin" logout={logout} />
        )}

        {seccion === "nueva" && <NuevaAuditoria />}

        {seccion === "reclamos" && <ReclamoInforme modo="admin" logout={logout} />}

        {seccion === "reportes" && (
          <ReportesAuditorias modo="admin" logout={logout} />
        )}
      </main>
    </div>
  );
}
